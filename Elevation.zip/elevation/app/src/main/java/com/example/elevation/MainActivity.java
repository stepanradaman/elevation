package com.example.elevation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import android.os.Bundle;
import android.widget.Button;
import com.github.mikephil.charting.components.Legend;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import android.view.View;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.widget.TextView;
import android.graphics.Color;
import java.util.ArrayList;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.listener.OnChartGestureListener;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;

public class MainActivity extends FragmentActivity implements OnMapReadyCallback {
    private GoogleMap mMap;
    private RequestQueue mQueue;
    private TextView mTextViewResult;
    private static final String TAG = "MainActivity";
    private LineChart mChart;
    final String[] elevationarray = new String[1];
    final ArrayList<String> stringarray = new ArrayList<String>();
    ArrayList<LatLng> points;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        points = new ArrayList<LatLng>();

        mTextViewResult = findViewById(R.id.text_view_result);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        mQueue = Volley.newRequestQueue(this);
        mChart = (LineChart) findViewById(R.id.linechart);

        mChart.setDragEnabled(true);
        mChart.setScaleEnabled(false);
        mChart.getDescription().setEnabled(false);
        mChart.setDrawGridBackground(false);
        mChart.getXAxis().setDrawGridLines(false);
        mChart.getAxisRight().setDrawGridLines(false);
        mChart.getAxisLeft().setDrawGridLines(false);
        mChart.getXAxis().setDrawAxisLine(false);
        mChart.getAxisLeft().setDrawAxisLine(false);
        mChart.getAxisRight().setDrawAxisLine(false);
        mChart.getLegend().setEnabled(false);
        mChart.setDescription(null);    // Hide the description
        mChart.getAxisLeft().setDrawLabels(false);
        mChart.getAxisRight().setDrawLabels(false);
        mChart.getXAxis().setDrawLabels(false);
        ArrayList<Entry> yValues = new ArrayList<>();
        for (int n=0; n<2; n++){
            float val = 0;
            yValues.add(new Entry(n, val));
        }
        LineDataSet set1 = new LineDataSet(yValues, "Data Set 1");
        set1.setFillAlpha(100);
        set1.setColor(Color.RED);
        set1.setLineWidth(2f);
        //set1.setDrawValues(false);
        set1.setDrawHighlightIndicators(false);
        set1.setCircleColor(Color.RED);
        ArrayList<ILineDataSet> dataSets = new ArrayList<>();
        dataSets.add(set1);
        LineData data = new LineData(dataSets);
        mChart.setData(data);

        Button buttonParse = findViewById(R.id.button_parse);
        buttonParse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.clear();
                mChart.clear();
                elevationarray[0] = null;
                stringarray.clear();
                mTextViewResult.setText("Count");
                points.clear();
            }
        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        elevationarray[0] = "1";

        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng point) {
                //BingMaps link
                String samplefirst = "http://dev.virtualearth.net/REST/v1/Elevation/List?points=";
                String com = ",";
                String lat = String.valueOf(point.latitude);
                String lon = String.valueOf(point.longitude);
                String samplesecond = "&key=";
                String bingkey = getResources().getString(R.string.bing_map_key);
                String url = samplefirst + lat + com + lon + samplesecond + bingkey;

                MarkerOptions marker = new MarkerOptions();
                marker.position(new LatLng(point.latitude, point.longitude));
                PolylineOptions polylineOptions = new PolylineOptions();
                polylineOptions.color(Color.BLUE);
                polylineOptions.width(3);

                JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                try {
                                    JSONArray jsonArray1 = response.getJSONArray("resourceSets");
                                    for (int i = 0; i < jsonArray1.length(); i++) {
                                        JSONObject employee1 = jsonArray1.getJSONObject(i);
                                        JSONArray jsonArray2 = employee1.getJSONArray("resources");
                                        for (int j = 0; j < jsonArray2.length(); j++) {
                                            JSONObject employee2 = jsonArray2.getJSONObject(j);
                                            JSONArray jsonArray3 = employee2.getJSONArray("elevations");
                                            for (int k = 0; k < jsonArray3.length(); k++) {
                                                String elevation = jsonArray3.getString(k);
                                                elevationarray[0] = elevation.toString();
                                                stringarray.add(elevationarray[0]);
                                                mTextViewResult.setText(String.valueOf(stringarray.size()));

                                                ArrayList<Entry> yValues = new ArrayList<>();
                                                for (int n=0; n<stringarray.size(); n++){
                                                    float val = Float.parseFloat(String.valueOf(stringarray.get(n)));
                                                    yValues.add(new Entry(n, val));
                                                }
                                                LineDataSet set1 = new LineDataSet(yValues, "Data Set 1");
                                                set1.setFillAlpha(100);
                                                set1.setColor(Color.RED);
                                                set1.setLineWidth(2f);
                                                set1.setDrawHighlightIndicators(false);
                                                set1.setCircleColor(Color.RED);
                                                ArrayList<ILineDataSet> dataSets = new ArrayList<>();
                                                dataSets.add(set1);
                                                LineData data = new LineData(dataSets);
                                                mChart.setData(data);
                                                mChart.invalidate();
                                            }
                                        }
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });
                mQueue.add(request);

                marker.title(elevationarray[0]);
                mMap.addMarker(marker);
                elevationarray[0] = null;
                points.add(point);
                polylineOptions.addAll(points);
                mMap.addPolyline(polylineOptions);
            }
        });
   }
}
